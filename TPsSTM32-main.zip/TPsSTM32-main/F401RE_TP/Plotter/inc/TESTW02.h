void test(int aIntegerNumber, float aFloatNumber);
